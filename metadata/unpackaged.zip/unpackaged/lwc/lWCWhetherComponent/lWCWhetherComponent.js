import { LightningElement } from 'lwc';

export default class LWCWhetherComponent extends LightningElement {


    handleSearch(){
        alert("Iam in handle search");
    }
}