import { LightningElement } from 'lwc';

export default class Populate_pli extends LightningElement {}